import sys
import unittest
from pathlib import Path

# Ensure project root is in sys.path
sys.path.insert(0, str(Path(__file__).parent.parent))

from duration import parse_duration


class TestDuration(unittest.TestCase):
    def test_parse_seconds(self):
        self.assertEqual(parse_duration("30s"), 30)

    def test_parse_minutes(self):
        self.assertEqual(parse_duration("15m"), 900)

    def test_parse_hours(self):
        self.assertEqual(parse_duration("2h"), 7200)

    def test_parse_days(self):
        self.assertEqual(parse_duration("1d"), 86400)
        self.assertEqual(parse_duration("7d"), 604800)

    def test_invalid_unit(self):
        with self.assertRaises(ValueError):
            parse_duration("10x")

    def test_invalid_value(self):
        with self.assertRaises(ValueError):
            parse_duration("abcs")

    def test_empty_string(self):
        with self.assertRaises(ValueError):
            parse_duration("")


if __name__ == "__main__":
    unittest.main()
