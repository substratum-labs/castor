# Duration Parser

Simple utility for parsing human-readable duration strings into integer seconds.

## Running Tests

```bash
python3 -m unittest tests/test_duration.py
```
